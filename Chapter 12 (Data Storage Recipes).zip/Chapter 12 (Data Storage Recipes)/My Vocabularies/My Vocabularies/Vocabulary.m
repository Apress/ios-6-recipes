//
//  Vocabulary.m
//  My Vocabularies
//
//  Created by Hans-Eric Grönlund on 9/4/12.
//  Copyright (c) 2012 Hans-Eric Grönlund. All rights reserved.
//

#import "Vocabulary.h"


@implementation Vocabulary

@dynamic name;
@dynamic words;

@end
