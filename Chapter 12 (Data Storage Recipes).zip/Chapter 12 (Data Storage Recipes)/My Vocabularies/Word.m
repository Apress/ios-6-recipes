//
//  Word.m
//  My Vocabularies
//
//  Created by Hans-Eric Grönlund on 9/4/12.
//  Copyright (c) 2012 Hans-Eric Grönlund. All rights reserved.
//

#import "Word.h"
#import "Vocabulary.h"


@implementation Word

@dynamic word;
@dynamic translation;
@dynamic vocabulary;

@end
