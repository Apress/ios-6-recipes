//
//  ViewController.h
//  Recipe 2.1: Auto Layout
//
//  Created by Hans-Eric Grönlund on 8/3/12.
//  Copyright (c) 2012 Hans-Eric Grönlund. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
