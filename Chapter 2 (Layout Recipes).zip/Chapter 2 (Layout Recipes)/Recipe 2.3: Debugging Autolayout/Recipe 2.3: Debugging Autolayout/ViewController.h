//
//  ViewController.h
//  Recipe 2.3: Debugging Autolayout
//
//  Created by Hans-Eric Grönlund on 8/25/12.
//  Copyright (c) 2012 Hans-Eric Grönlund. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
