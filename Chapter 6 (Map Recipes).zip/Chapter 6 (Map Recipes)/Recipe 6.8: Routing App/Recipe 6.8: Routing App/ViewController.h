//
//  ViewController.h
//  Recipe 6.8: Routing App
//
//  Created by Hans-Eric Grönlund on 7/7/12.
//  Copyright (c) 2012 Hans-Eric Grönlund. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *routingLabel;

@end
