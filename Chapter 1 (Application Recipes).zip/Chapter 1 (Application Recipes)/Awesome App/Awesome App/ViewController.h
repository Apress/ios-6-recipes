//
//  ViewController.h
//  Awesome App
//
//  Created by Hans-Eric Grönlund on 8/12/12.
//  Copyright (c) 2012 Hans-Eric Grönlund. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)showAboutUsView:(id)sender;

@end
