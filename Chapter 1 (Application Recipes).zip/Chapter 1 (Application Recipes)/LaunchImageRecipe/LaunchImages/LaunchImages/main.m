//
//  main.m
//  LaunchImages
//
//  Created by Hans-Eric Grönlund on 2012-05-18.
//  Copyright (c) 2012 Know IT. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
