//
//  ViewController.h
//  LaunchImages
//
//  Created by Hans-Eric Grönlund on 2012-05-18.
//  Copyright (c) 2012 Know IT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController

@end
