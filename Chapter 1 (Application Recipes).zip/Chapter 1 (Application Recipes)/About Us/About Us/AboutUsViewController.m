//
//  ViewController.m
//  About Us
//
//  Created by Hans-Eric Grönlund on 8/12/12.
//  Copyright (c) 2012 Hans-Eric Grönlund. All rights reserved.
//

#import "AboutUsViewController.h"

@interface AboutUsViewController ()

@end

@implementation AboutUsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
