//
//  ViewController.h
//  About Us
//
//  Created by Hans-Eric Grönlund on 8/12/12.
//  Copyright (c) 2012 Hans-Eric Grönlund. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUsViewController : UIViewController

@end
