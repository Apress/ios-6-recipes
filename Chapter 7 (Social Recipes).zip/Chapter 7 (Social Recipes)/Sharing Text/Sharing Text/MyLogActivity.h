//
//  MyLogActivity.h
//  Sharing Text
//
//  Created by Hans-Eric Grönlund on 8/16/12.
//  Copyright (c) 2012 Hans-Eric Grönlund. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyLogActivity : UIActivity

@property (strong, nonatomic)NSString *logMessage;

@end
