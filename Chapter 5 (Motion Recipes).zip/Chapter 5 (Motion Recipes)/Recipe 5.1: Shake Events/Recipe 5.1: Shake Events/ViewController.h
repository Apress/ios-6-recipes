//
//  ViewController.h
//  Recipe 5.1: Shake Events
//
//  Created by Hans-Eric Grönlund on 6/14/12.
//  Copyright (c) 2012 Know IT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
